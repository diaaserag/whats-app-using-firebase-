//
//  regestrScreen.swift
//  messenger
//
//  Created by diaa on 19/08/2021.
//

import UIKit
import Firebase
class regestrScreen: UIViewController {


    @IBOutlet weak var textPass: UITextField!
    @IBOutlet weak var textEmail: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func buttonRegister(_ sender: Any) {
        if textEmail.text != "" && textPass.text != ""{
            Auth.auth().createUser(withEmail: textEmail.text!, password: textPass.text!, completion: {(user,error) in
                if error != nil{
                    print(error)
                }
                else{
                    print("user is created")
                    let go = self.storyboard?.instantiateViewController(withIdentifier: "chat")as? chatScreen
                    self.present(go!, animated: true, completion: nil)
                }
            })
        }
    }
    


}
