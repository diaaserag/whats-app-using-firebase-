//
//  TableViewCell.swift
//  messenger
//
//  Created by diaa on 19/08/2021.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var lblUserName: UILabel!
    
    @IBOutlet weak var imagUser: UIImageView!
    
    @IBOutlet weak var lblChat: UILabel!
}
