//
//  logInScreen.swift
//  messenger
//
//  Created by diaa on 19/08/2021.
//

import UIKit
import Firebase
class logInScreen: UIViewController {

    @IBOutlet weak var textPass: UITextField!
    @IBOutlet weak var textEmail: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonLogIn(_ sender: Any) {
        Auth.auth().signIn(withEmail: textEmail.text!, password: textPass.text!){user,error in
            if error != nil{
                print(error)
            }
            else{
                print("log in is sucsses")
                let go = self.storyboard?.instantiateViewController(withIdentifier: "chat")as? chatScreen
                self.present(go!, animated: true, completion: nil)
            }
        }
    }
    


}
