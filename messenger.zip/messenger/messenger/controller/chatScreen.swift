//
//  chatScreen.swift
//  messenger
//
//  Created by diaa on 19/08/2021.
//

import UIKit
import Firebase
class chatScreen: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var arrmassag : [massageData] = [massageData]()
    @IBOutlet weak var buttonSND: UIButton!
    @IBOutlet weak var textMassag: UITextField!
    @IBOutlet weak var tableChat: UITableView!
    @IBOutlet weak var barTITIL: UINavigationBar!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableChat.delegate = self
        tableChat.dataSource = self
        title = "Chat"
        config()
        tableChat.separatorStyle = .none
        getdata()
    }
    @IBAction func barButtonLogOut(_ sender: Any) {
        do{
            try Auth.auth().signOut()
        }
        catch{
            print(error)
        }
        let go = self.storyboard?.instantiateViewController(withIdentifier: "home")as? ViewController
        self.present(go!, animated: true, completion: nil)
    }
    
    //MARK:- SEND DATA TO FIRE BASE
    @IBAction func buttonSend(_ sender: UIButton) {
        if textMassag.text != ""{
        textMassag.isEnabled = false
        textMassag.endEditing(true)
        buttonSND.isEnabled = false
        let dataPath = Database.database().reference().child("massadg")
        let dataDictionry = ["sender": Auth.auth().currentUser?.email , "text" : textMassag.text]
        dataPath.childByAutoId().setValue(dataDictionry){(error,ref) in
            if (error) != nil{
                print(error)
            }
            else{
                self.textMassag.isEnabled = true
                self.textMassag.endEditing(false)
                self.buttonSND.isEnabled = true
                self.textMassag.text = ""
            }
        }
        }
    }
    func config(){
        tableChat.rowHeight = UITableView.automaticDimension
        tableChat.estimatedRowHeight = 120.0
    }
}


//MARK: TABLE
//>>>>>>>>>>>>>>>>>>>>>>>>>>>
extension chatScreen{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrmassag.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableChat.dequeueReusableCell(withIdentifier: "textcell", for: indexPath)as? TableViewCell
        cell?.lblChat.text = arrmassag[indexPath.row].massageBody
        cell?.lblUserName.text = arrmassag[indexPath.row].sender
        cell?.imagUser.image = UIImage(systemName: "heart")
        if ((cell?.lblUserName.text == Auth.auth().currentUser?.email) ){
            cell?.lblChat.backgroundColor = #colorLiteral(red: 0.1411764771, green: 0.3960784376, blue: 0.5647059083, alpha: 1)
            cell?.imagUser.backgroundColor = #colorLiteral(red: 0.3098039329, green: 0.01568627544, blue: 0.1294117719, alpha: 1)
        }
        else{
            cell?.lblChat.backgroundColor = #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
            cell?.imagUser.backgroundColor = #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1)
        }
        return cell!
    }
}
//MARK:- GET DATA FROM FIREBASE
/////////////////////////////////////////////////////////////////////////////
extension chatScreen{
    func getdata(){
        let dataPath = Database.database().reference().child("massadg")
        dataPath.observe(.childAdded, with: { [self](snapshot) in
            let snap = snapshot.value as! Dictionary<String,String>
            let text = snap["text"]
            let sender = snap["sender"]
            let massag = massageData()
            massag.massageBody = text!
            massag.sender = sender!
            arrmassag.append(massag)
            config()
            tableChat.reloadData()
        })
    }
}
