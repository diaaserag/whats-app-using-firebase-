//
//  model.swift
//  messenger
//
//  Created by diaa on 19/08/2021.
//

import Foundation
class massageData {
    var sender : String = ""
    var massageBody : String = ""
}
